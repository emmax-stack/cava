'use strict';
// Cava — servidor: datos en la nube, push real, alertas y recordatorios a clientes.
const express = require('express'), crypto = require('crypto'), fs = require('fs'), path = require('path'), webpush = require('web-push'), nodemailer = require('nodemailer'), R = require('./report'), compression = require('compression');

const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const PIN = process.env.APP_PIN || '';
const TZ = process.env.TZ_NAME || 'America/Caracas';
const DRY = !(process.env.WA_TOKEN && process.env.WA_PHONE_ID); // sin credenciales de WhatsApp: solo registra, no envía
const MAILDRY = !process.env.SMTP_HOST; // sin SMTP: los correos se SIMULAN (quedan en el registro)
const SMTP_PORT = +(process.env.SMTP_PORT || 587);
const transporter = MAILDRY ? null : nodemailer.createTransport({ host: process.env.SMTP_HOST, port: SMTP_PORT, secure: SMTP_PORT === 465, auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined });

fs.mkdirSync(path.join(DATA, 'backups'), { recursive: true });
const F = { state: path.join(DATA, 'state.json'), meta: path.join(DATA, 'meta.json'), vapid: path.join(DATA, 'vapid.json'), secret: path.join(DATA, 'secret.txt') };
const rd = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } };
const wr = (f, o) => { const t = f + '.tmp'; fs.writeFileSync(t, JSON.stringify(o)); fs.renameSync(t, f); };

let db = rd(F.state, { rev: 0, state: null });
let meta = rd(F.meta, { subs: [], done: {}, remind: {}, notified: {}, log: [] });
let VAPID = rd(F.vapid, null);
if (!VAPID) { VAPID = webpush.generateVAPIDKeys(); wr(F.vapid, VAPID); }
webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', VAPID.publicKey, VAPID.privateKey);

function log(m) { const l = new Date().toISOString().slice(0, 19) + ' ' + m; console.log(l); meta.log = (meta.log || []).concat([l]).slice(-200); }

// ---------- utilidades de fecha y cálculo (mismas reglas que la app) ----------
const addDays = (s, n) => { const d = new Date(s + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const diff = (a, b) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 864e5);
const sum = g => (g || []).reduce((a, x) => a + x.m, 0);
const saldo = v => v.k * v.p - sum(v.g);
const money = n => '$' + Number(n).toLocaleString('es', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const stock = (S, pid) => (S.m || []).reduce((a, m) => m.pid === pid ? a + (m.t === 'in' ? m.q : -m.q) : a, 0);
const cname = (S, id) => (S.c.find(c => c.id === id) || {}).n || '—';
function nowTZ(d = new Date()) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: TZ, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).formatToParts(d).map(x => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}` };
}

function digest(S, today) {
  const dsp = (S.d || []).filter(d => d.st === 'p' && d.f <= today);
  const ven = (S.v || []).filter(v => saldo(v) > 0.005 && addDays(v.f, v.pl) < today);
  const venTot = ven.reduce((a, v) => a + saldo(v), 0);
  const venCli = new Set(ven.map(v => v.cid)).size;
  const low = (S.p || []).filter(p => p.min > 0 && stock(S, p.id) <= p.min).map(p => p.n);
  const prov = (S.o || []).filter(o => saldo(o) > 0.005 && addDays(o.f, o.pl) <= addDays(today, 2));
  const provTot = prov.reduce((a, o) => a + saldo(o), 0);
  const parts = [];
  if (dsp.length) parts.push(`${dsp.length} despacho(s) para hoy`);
  if (venCli) parts.push(`${venCli} cliente(s) con pagos vencidos por ${money(venTot)}`);
  if (low.length) parts.push(`stock bajo: ${low.join(', ')}`);
  if (prov.length) parts.push(`por pagar a proveedores: ${money(provTot)}`);
  return { dsp, ven, venTot, venCli, low, prov, provTot, text: parts.length ? parts.join(' · ') : 'Todo al día ✅' };
}

// ---------- envíos ----------
async function pushAll(title, body, tag) {
  let n = 0;
  for (const s of [...meta.subs]) {
    try { await webpush.sendNotification(s, JSON.stringify({ title, body, tag: tag || 'cq' })); n++; }
    catch (e) { if (e.statusCode === 404 || e.statusCode === 410) meta.subs = meta.subs.filter(x => x.endpoint !== s.endpoint); else log('push error ' + (e.statusCode || e.message)); }
  }
  return n;
}

async function wa(to, tpl, params) {
  const clean = params.map(t => ({ type: 'text', text: String(t).replace(/[\n\t]+/g, ' ').slice(0, 500) }));
  log(`WhatsApp → ${to} [${tpl}] ${clean.map(x => x.text).join(' | ')}${DRY ? '  (SIMULADO)' : ''}`);
  if (DRY) return true;
  try {
    const r = await fetch(`https://graph.facebook.com/v20.0/${process.env.WA_PHONE_ID}/messages`, {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + process.env.WA_TOKEN, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'template', template: { name: tpl, language: { code: process.env.WA_LANG || 'es' }, components: [{ type: 'body', parameters: clean }] } })
    });
    if (!r.ok) { log('WhatsApp error ' + r.status + ' ' + (await r.text()).slice(0, 200)); return false; }
    return true;
  } catch (e) { log('WhatsApp falló: ' + e.message); return false; }
}

// ---------- reportes por correo ----------
function buildMail(S, kind, today, rcp) {
  const rg = R.range(kind, today), r = R.build(S, rg.from, rg.to, rg.label, today);
  return { r, mail: { from: process.env.SMTP_FROM || process.env.SMTP_USER || 'cobranza@localhost', to: rcp, subject: `Reporte ${rg.label} — Cava`, html: R.html(r), attachments: [{ filename: `ventas-${rg.from}_${rg.to}.csv`, content: R.csv(S, rg.from, rg.to) }] } };
}
async function sendReport(S, kind, today, to) {
  const rcp = String(to || ((S.cfg || {}).srv || {}).mail || '').trim();
  if (!rcp) return { error: 'Falta el correo: ponlo en Despachos → Servidor → Correo para recibir reportes' };
  const { r, mail } = buildMail(S, kind, today, rcp);
  log(`Correo → ${rcp} [${mail.subject}] ventas ${money(r.ventas)} · ganancia ${money(r.gan)}${MAILDRY ? '  (SIMULADO)' : ''}`);
  if (MAILDRY) return { ok: true, simulated: true, to: rcp };
  try { await transporter.sendMail(mail); return { ok: true, to: rcp }; }
  catch (e) { log('Correo falló: ' + e.message); return { error: 'No se pudo enviar el correo: ' + e.message }; }
}

// ---------- tareas automáticas (se ejecutan cada minuto) ----------
async function jobs(now = nowTZ()) {
  const S = db.state, out = [];
  if (!S) return out;
  const cfg = Object.assign({ hora: '08:00', horaC: '10:00', every: 3, cli: true, owner: '', mail: '', rw: true, rm: true, horaR: '08:00' }, (S.cfg || {}).srv);

  // 1) Resumen diario para ti (push + WhatsApp opcional)
  if (now.time >= cfg.hora && meta.done.daily !== now.date) {
    meta.done.daily = now.date;
    const D = digest(S, now.date);
    await pushAll('Resumen de hoy', D.text, 'daily');
    if (cfg.owner) await wa(cfg.owner, process.env.WA_TPL_OWNER || 'resumen_diario', [D.text]);
    out.push('resumen');
  }
  // 2) Aviso a la hora de un despacho concreto
  for (const d of (S.d || [])) {
    if (d.st === 'p' && d.h && d.f <= now.date && (d.f < now.date || now.time >= d.h) && !meta.notified[d.id]) {
      meta.notified[d.id] = now.date;
      const p = (S.p || []).find(x => x.id === d.pid) || {};
      await pushAll('⏰ Hora de despachar', `${cname(S, d.cid)}: ${d.k} ${p.u || ''} ${p.n || ''}`, 'd' + d.id);
      out.push('despacho:' + d.id);
    }
  }
  // 3) Recordatorios de pago a clientes por WhatsApp
  if (cfg.cli && now.time >= cfg.horaC && meta.done.cli !== now.date) {
    meta.done.cli = now.date;
    const by = {};
    for (const v of (S.v || [])) {
      const s = saldo(v), dv = addDays(v.f, v.pl);
      if (s > 0.005 && dv < now.date) { const b = by[v.cid] || (by[v.cid] = { tot: 0, old: dv }); b.tot += s; if (dv < b.old) b.old = dv; }
    }
    let sent = 0;
    for (const cid of Object.keys(by)) {
      const c = S.c.find(x => x.id === cid);
      if (!c || !c.t || c.nr) continue;
      if (meta.remind[cid] && diff(meta.remind[cid], now.date) < cfg.every) continue;
      if (await wa(c.t, process.env.WA_TPL_CLIENT || 'recordatorio_pago', [c.n, money(by[cid].tot), by[cid].old])) { meta.remind[cid] = now.date; sent++; out.push('cliente:' + c.n); }
    }
    if (sent) await pushAll('Recordatorios enviados', `Se avisó a ${sent} cliente(s) con pagos vencidos.`, 'cli');
  }
  // 4) Reportes por correo: semanal (lunes) y mensual (día 1)
  if (cfg.mail && now.time >= (cfg.horaR || '08:00')) {
    const dow = new Date(now.date + 'T12:00:00Z').getUTCDay();
    for (const [kind, due, key] of [['week', cfg.rw !== false && dow === 1, 'rw'], ['month', cfg.rm !== false && now.date.slice(8) === '01', 'rm']]) {
      if (!due || meta.done[key] === now.date) continue;
      meta.done[key] = now.date;
      const x = await sendReport(S, kind, now.date);
      if (x.error) await pushAll('Reporte no enviado', x.error, 'rep'); else out.push('reporte-' + kind);
    }
  }
  // 5) Respaldo diario
  const bf = path.join(DATA, 'backups', now.date + '.json');
  if (!fs.existsSync(bf) && fs.existsSync(F.state)) {
    fs.copyFileSync(F.state, bf);
    for (const x of fs.readdirSync(path.join(DATA, 'backups')).sort().slice(0, -30)) fs.unlinkSync(path.join(DATA, 'backups', x));
  }
  wr(F.meta, meta);
  return out;
}

// ---------- sesión con PIN ----------
// Sesiones guardadas en el servidor: se pueden cerrar y quedan invalidadas de verdad.
function newSession() {
  const id = crypto.randomBytes(32).toString('hex'), now = Date.now();
  meta.sessions = meta.sessions || {};
  for (const k of Object.keys(meta.sessions)) if (meta.sessions[k] < now) delete meta.sessions[k];
  meta.sessions[id] = now + 30 * 864e5; wr(F.meta, meta); return id;
}
const validSid = id => !!id && !!meta.sessions && meta.sessions[id] > Date.now();

// Validación del estado que envía la app (evita guardar datos corruptos). Campos numéricos por lista.
const NUM = { v: ['k', 'p'], o: ['k', 'p'], d: ['k', 'p'], m: ['q'] };
function validState(s) {
  if (!s || typeof s !== 'object' || Array.isArray(s)) return 'Datos no válidos';
  if (!Array.isArray(s.c) || !Array.isArray(s.v)) return 'Faltan los clientes o las ventas';
  for (const k of ['c', 'v', 'p', 'm', 's', 'o', 'd']) {
    if (s[k] === undefined) continue;
    if (!Array.isArray(s[k])) return `La lista "${k}" no es válida`;
    for (const x of s[k]) {
      if (!x || typeof x !== 'object' || typeof x.id !== 'string') return `Hay un elemento sin identificador en "${k}"`;
      for (const f of (NUM[k] || [])) if (x[f] !== undefined && !Number.isFinite(x[f])) return `Hay un número no válido en "${k}"`;
    }
  }
  return null;
}
const getSid = req => { const c = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith('sid=')); return c ? c.slice(4) : ''; };
const fails = {};

const app = express();
app.set('trust proxy', 1);
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
  });
  next();
});
app.use(compression());
app.use(express.json({ limit: '50mb' })); // admite cuerpos comprimidos (gzip) desde la app
// Solo estos archivos son públicos (el resto, como server.js o los datos, nunca se sirve).
const PUBLIC_FILES = new Set(['index.html', 'sw.js', 'manifest.json', 'icon.svg', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png']);
const sendPublic = (name, res, next) => res.sendFile(path.join(__dirname, name), { headers: { 'Cache-Control': /\.(png|svg)$/.test(name) ? 'public, max-age=604800' : 'no-cache' } }, err => err && next(err));
app.get('/', (req, res, next) => sendPublic('index.html', res, next));
app.get('/:file', (req, res, next) => PUBLIC_FILES.has(req.params.file) ? sendPublic(req.params.file, res, next) : next());
app.get('/health', (req, res) => res.send('ok'));

app.post('/api/login', (req, res) => {
  const f = fails[req.ip] || { n: 0, t: 0 };
  if (f.n >= 5 && Date.now() - f.t < 9e5) return res.status(429).json({ error: 'Demasiados intentos, espera 15 minutos' });
  const h = x => crypto.createHash('sha256').update(String(x)).digest();
  if (PIN && crypto.timingSafeEqual(h((req.body || {}).pin || ''), h(PIN))) {
    delete fails[req.ip];
    const secure = req.secure ? '; Secure' : '';
    res.setHeader('Set-Cookie', `sid=${newSession()}; HttpOnly; Path=/; Max-Age=2592000; SameSite=Lax${secure}`);
    return res.json({ ok: true });
  }
  fails[req.ip] = { n: f.n + 1, t: Date.now() };
  res.status(401).json({ error: 'PIN incorrecto' });
});
app.post('/api/logout', (req, res) => {
  const id = getSid(req);
  if (meta.sessions && meta.sessions[id]) { delete meta.sessions[id]; wr(F.meta, meta); }
  res.setHeader('Set-Cookie', `sid=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax${req.secure ? '; Secure' : ''}`);
  res.json({ ok: true });
});
app.use('/api', (req, res, next) => validSid(getSid(req)) ? next() : res.status(401).json({ error: 'auth' }));

// ---------- datos en la nube ----------
app.get('/api/state', (req, res) => {
  if (db.rev > 0 && +req.query.rev === db.rev) return res.json({ same: true, rev: db.rev });
  res.json({ rev: db.rev, state: db.state });
});
app.put('/api/state', (req, res) => {
  const { rev, state } = req.body || {};
  const err = validState(state);
  if (err) return res.status(400).json({ error: err });
  if (rev !== db.rev) return res.json({ conflict: true, rev: db.rev, state: db.state }); // otro dispositivo guardó antes
  db = { rev: db.rev + 1, state };
  wr(F.state, db);
  res.json({ rev: db.rev });
});

// ---------- push ----------
app.get('/api/push/key', (req, res) => res.json({ key: VAPID.publicKey }));
app.post('/api/push/subscribe', (req, res) => {
  const s = (req.body || {}).sub;
  if (!s || !s.endpoint) return res.status(400).json({ error: 'suscripción inválida' });
  meta.subs = meta.subs.filter(x => x.endpoint !== s.endpoint).concat([s]);
  wr(F.meta, meta);
  res.json({ ok: true, devices: meta.subs.length });
});
app.post('/api/push/test', async (req, res) => { const n = await pushAll('Prueba', 'Las notificaciones push funcionan ✅', 'test'); wr(F.meta, meta); res.json({ sent: n }); });
app.get('/api/report/preview', (req, res) => {
  if (!db.state) return res.status(404).send('Aún no hay datos');
  const { r } = buildMail(db.state, ['week', 'month'].includes(req.query.kind) ? req.query.kind : 'current', nowTZ().date, 'x');
  res.type('html').send('<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + R.html(r));
});
app.post('/api/report/send', async (req, res) => {
  if (!db.state) return res.status(400).json({ error: 'Aún no hay datos' });
  const kind = ['week', 'month'].includes((req.body || {}).kind) ? req.body.kind : 'current';
  const x = await sendReport(db.state, kind, nowTZ().date); wr(F.meta, meta); res.json(x);
});
app.get('/api/log', (req, res) => res.json({ dry: DRY, subs: meta.subs.length, log: meta.log }));

app.use((err, req, res, next) => { // errores siempre en JSON, con mensaje claro
  if (res.headersSent) return next(err);
  const st = err.status || 500;
  res.status(st).json({ error: err.type === 'entity.too.large' ? 'Los datos son demasiado grandes' : st < 500 ? 'Solicitud no válida' : 'Error del servidor' });
});

module.exports = { app, jobs, digest, buildMail, setState: s => { db = { rev: db.rev + 1, state: s }; }, meta: () => meta };

if (require.main === module) {
  if (!PIN) { console.error('Falta la variable APP_PIN (el PIN para entrar a la app).'); process.exit(1); }
  app.listen(PORT, () => log(`Servidor listo en el puerto ${PORT} · zona horaria ${TZ} · WhatsApp ${DRY ? 'en modo SIMULADO' : 'activo'}`));
  const run = () => jobs().catch(e => console.error('jobs', e));
  setTimeout(run, 5000); setInterval(run, 60000);
}
