'use strict';
// Reportes por correo: cálculo del periodo, HTML del correo y CSV adjunto.
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const money = n => '$' + Number(n).toLocaleString('es', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const r2 = n => Math.round(n * 100) / 100;
const sum = g => (g || []).reduce((a, x) => a + x.m, 0);
const saldo = v => v.k * v.p - sum(v.g);
const addDays = (s, n) => { const d = new Date(s + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const inR = (d, a, b) => d >= a && d <= b;
const cn = (S, id) => ((S.c || []).find(c => c.id === id) || {}).n || '—';
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

function costoProm(S, pid) { let q = 0, t = 0; for (const o of S.o || []) if (o.pid === pid) { q += o.k; t += o.k * o.p; } return q > 0 ? t / q : null; }
function stock(S, pid) { return (S.m || []).reduce((a, m) => m.pid === pid ? a + (m.t === 'in' ? m.q : -m.q) : a, 0); }

// kind: 'week' (7 días previos), 'month' (mes anterior completo), 'current' (mes en curso hasta hoy)
function range(kind, today) {
  if (kind === 'week') return { from: addDays(today, -7), to: addDays(today, -1), label: 'semanal' };
  if (kind === 'month') {
    const d = new Date(today + 'T12:00:00Z'), y = d.getUTCFullYear(), m = d.getUTCMonth();
    const s = new Date(Date.UTC(y, m - 1, 1, 12)), e = new Date(Date.UTC(y, m, 0, 12));
    return { from: s.toISOString().slice(0, 10), to: e.toISOString().slice(0, 10), label: `mensual de ${MESES[s.getUTCMonth()]} ${s.getUTCFullYear()}` };
  }
  return { from: today.slice(0, 8) + '01', to: today, label: 'del mes en curso' };
}

function build(S, from, to, label, today) {
  const V = (S.v || []).filter(v => inR(v.f, from, to));
  let ventas = 0, costo = 0, sinCosto = 0; const prod = {}, cli = {};
  for (const v of V) {
    const t = v.k * v.p, cp = v.pid ? costoProm(S, v.pid) : null;
    ventas += t; if (cp === null) sinCosto++; else costo += v.k * cp;
    const pr = (S.p || []).find(p => p.id === v.pid), n = pr ? pr.n : (v.q || '—');
    const P = prod[n] || (prod[n] = { n, u: pr ? pr.u : '', q: 0, t: 0 }); P.q += v.k; P.t += t;
    const c = cn(S, v.cid), C = cli[c] || (cli[c] = { n: c, t: 0 }); C.t += t;
  }
  let cobrado = 0, pagado = 0;
  for (const v of S.v || []) for (const x of v.g || []) if (inR(x.f, from, to)) cobrado += x.m;
  for (const o of S.o || []) for (const x of o.g || []) if (inR(x.f, from, to)) pagado += x.m;
  // situación al día de hoy
  const deud = {}; let porCobrar = 0, vencido = 0;
  for (const v of S.v || []) {
    const s = saldo(v); if (s <= 0.005) continue;
    const dv = addDays(v.f, v.pl), c = cn(S, v.cid), D = deud[c] || (deud[c] = { n: c, s: 0, ven: 0, old: dv });
    porCobrar += s; D.s += s; if (dv < today) { vencido += s; D.ven += s; } if (dv < D.old) D.old = dv;
  }
  let debo = 0; const prov = {};
  for (const o of S.o || []) { const s = saldo(o); if (s > 0.005) { debo += s; const n = ((S.s || []).find(x => x.id === o.sid) || {}).n || '—'; prov[n] = (prov[n] || 0) + s; } }
  let inv = 0; const low = [];
  for (const p of S.p || []) { const s = stock(S, p.id), c = costoProm(S, p.id); if (c !== null && s > 0) inv += s * c; if (p.min > 0 && s <= p.min) low.push(`${p.n} (${r2(s)} ${p.u})`); }
  const gan = ventas - costo;
  return {
    label, from, to, today, ventas, costo, gan, mar: ventas > 0 ? gan / ventas * 100 : 0, cobrado, pagado, nVentas: V.length, sinCosto,
    prods: Object.values(prod).sort((a, b) => b.t - a.t), clis: Object.values(cli).sort((a, b) => b.t - a.t).slice(0, 5),
    deudores: Object.values(deud).sort((a, b) => b.s - a.s), porCobrar, vencido, debo,
    provs: Object.entries(prov).sort((a, b) => b[1] - a[1]), inv, low, pos: porCobrar + inv - debo
  };
}

function html(r) {
  const td = 'padding:6px 8px;border-bottom:1px solid #eee';
  const row = (a, b, st = '') => `<tr><td style="${td}">${a}</td><td style="${td};text-align:right;${st}"><b>${b}</b></td></tr>`;
  const tb = rows => `<table style="width:100%;border-collapse:collapse;font-size:14px">${rows}</table>`;
  const h = t => `<h3 style="margin:22px 0 6px;color:#8a5a00">${t}</h3>`;
  const none = '<div style="color:#7a6e55;font-size:13px">Sin datos</div>';
  const red = 'color:#c62828', grn = 'color:#2e7d32';
  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:640px;margin:auto;color:#2b2412;padding:8px">
<h2 style="margin:0">🧀 Reporte ${esc(r.label)}</h2><div style="color:#7a6e55;font-size:13px">${r.from} al ${r.to}</div>
${h('Resumen del periodo')}${tb(row(`Ventas (${r.nVentas})`, money(r.ventas)) + row('Costo de la mercancía vendida', money(r.costo)) + row('Ganancia neta', money(r.gan), r.gan >= 0 ? grn : red) + row('Margen', r.mar.toFixed(1) + '%') + row('Cobrado en el periodo', money(r.cobrado)) + row('Pagado a proveedores', money(r.pagado)))}
${r.sinCosto ? `<div style="font-size:12px;color:#b26a00;margin-top:6px">⚠️ ${r.sinCosto} venta(s) de productos sin compras registradas: su costo cuenta como $0.</div>` : ''}
${h('Productos vendidos')}${r.prods.length ? tb(r.prods.map(p => row(`${esc(p.n)} · ${r2(p.q)} ${esc(p.u)}`, money(p.t))).join('')) : none}
${h('Mejores clientes del periodo')}${r.clis.length ? tb(r.clis.map(c => row(esc(c.n), money(c.t))).join('')) : none}
${h('Quién me debe hoy')}${tb(row('Total por cobrar', money(r.porCobrar)) + row('De eso, vencido', money(r.vencido), r.vencido > 0 ? red : ''))}
${r.deudores.length ? '<div style="height:6px"></div>' + tb(r.deudores.slice(0, 10).map(d => row(esc(d.n) + (d.ven > 0 ? ` <span style="${red};font-size:12px">(vencido desde ${d.old})</span>` : ''), money(d.s))).join('')) : ''}
${h('Lo que debo a proveedores')}${r.provs.length ? tb(r.provs.map(p => row(esc(p[0]), money(p[1]))).join('') + row('Total', money(r.debo))) : none}
${h('Inventario')}${tb(row('Valor a costo', money(r.inv)) + row('Posición neta (por cobrar + inventario − deudas)', money(r.pos), r.pos >= 0 ? grn : red))}
${r.low.length ? `<div style="font-size:13px;color:#c62828;margin-top:6px">Stock bajo: ${r.low.map(esc).join(', ')}</div>` : ''}
<div style="color:#999;font-size:11px;margin-top:24px">Adjunto: detalle de ventas del periodo en CSV. Generado automáticamente por Cava.</div></div>`;
}

function csv(S, from, to) {
  const q = x => '"' + String(x).replace(/"/g, '""') + '"';
  const rows = [['Fecha', 'Cliente', 'Producto', 'Cantidad', 'Precio', 'Total', 'Cobrado', 'Saldo', 'Vence'].map(q)];
  for (const v of (S.v || []).filter(v => inR(v.f, from, to)))
    rows.push([q(v.f), q(cn(S, v.cid)), q(v.q || ''), v.k, v.p, r2(v.k * v.p), r2(sum(v.g)), r2(saldo(v)), q(addDays(v.f, v.pl))]);
  return '\ufeff' + rows.map(r => r.join(',')).join('\r\n');
}

module.exports = { range, build, html, csv };
