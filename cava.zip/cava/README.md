# Cava

Tu negocio de quesos en el celular y en la tablet: ventas, cobros, despachos, stock, proveedores, reportes, notas de venta para tus clientes, avisos y recordatorios.

- **App:** se instala desde Chrome como una app más (PWA), con logo propio, notas de venta en blanco y negro y diseño que se adapta al teléfono, a la tablet y a la pantalla horizontal. Abre sin internet.
- **Servidor:** guarda tus datos en la nube con PIN, manda notificaciones push, recordatorios de pago por WhatsApp y reportes por correo.

## 0. Usarla YA en Chrome, sin servidor
Enlace: **https://claude.ai/artifact/41vqdHo9VQ3xEZE2F8byzK**
1. Ábrelo en **Chrome** (si te lo pide, inicia sesión en claude.ai con tu cuenta; el enlace es privado tuyo).
2. Menú **⋮ → Añadir a pantalla de inicio** (o *Instalar aplicación* si aparece). Queda un icono de Cava que abre la app.
3. Haz lo mismo en la tablet.
- **Qué incluye:** todo: ventas, despachos, cobros, compras, stock, reportes, notas de venta, recordatorios con sonido (suenan con la app abierta), temas y logo.
- **Cómo guarda:** los datos quedan **en ese aparato** y funcionan sin internet, pero **no se comparten** entre el celular y la tablet. Para pasarlos: **⚙ Ajustes → Respaldo de datos → Mostrar mis datos**, copia el texto y pégalo en el otro aparato con *Importar*. La app te avisa si pasan 7 días sin copia.
- **Cuidado:** si borras los datos del navegador, pierdes lo guardado en ese aparato. Haz copias.
- **Qué no incluye:** avisos automáticos por WhatsApp, notificaciones con la app cerrada, reportes por correo ni sincronización entre aparatos. Eso lo da el servidor (sección 1).
- **Nota de venta:** mantén pulsada la foto para guardarla o compartirla.

## 1. Ponerla en internet (una sola vez, desde el celular)
Necesitas dos cuentas: **GitHub** (gratis) y **Render** (de pago, ver costo). Costo verificado en la página de precios de Render: plan básico **US$7 al mes** (0,5 CPU, 512 MB) más **US$0,25 al mes por 1 GB de disco** donde se guardan tus datos; total ≈ **US$7,25 al mes**. Los planes gratis de Render **no sirven**: no permiten disco y perderías los datos.

**A. Subir los archivos a GitHub**
1. Descomprime `cava.zip` en tu celular (app Archivos → mantén pulsado el zip → Extraer).
2. En Chrome entra a github.com, crea tu cuenta y toca **New repository** (nuevo repositorio). Nombre `cava`, déjalo en **Private** y créalo. Si no ves las opciones, activa **Sitio de escritorio** en el menú ⋮ de Chrome.
3. En el repositorio vacío toca el enlace **uploading an existing file**. Selecciona **estos 13 archivos** de la carpeta `cava` (no hace falta subir `tests` ni los demás): `server.js`, `report.js`, `package.json`, `package-lock.json`, `render.yaml`, `index.html`, `sw.js`, `manifest.json`, `icon.svg`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`.
4. Toca **Commit changes**.

**B. Crear el servidor en Render**
1. Entra a render.com y regístrate con tu cuenta de GitHub.
2. Toca **New + → Blueprint**, elige el repositorio `cava` y conéctalo. Render lee solo el archivo `render.yaml` (ya trae el disco y la configuración).
3. Te pedirá **APP_PIN**: escribe el PIN que usarás para entrar (solo tú lo sabrás). Agrega tu tarjeta cuando te la pida y toca **Apply**.
4. Espera unos minutos hasta que diga **Live**. Arriba verás la dirección de tu app, algo como `https://cava-xxxx.onrender.com`.
5. **Zona horaria:** viene en `America/Caracas`. Si estás en otra, en Render → tu servicio → **Environment** cambia `TZ_NAME` (por ejemplo `America/New_York`). Define a qué hora llegan los avisos.

Si prefieres otro proveedor, sirve cualquiera con Node 18+, HTTPS, siempre encendido y disco persistente (por ejemplo un VPS pequeño con Caddy delante).

## 2. Instalarla en tu Honor y en tu tablet Hyundai
En cada aparato:
1. Abre en **Chrome** la dirección de tu app e ingresa tu PIN.
2. Menú **⋮ → Instalar aplicación** (o *Añadir a pantalla de inicio*). Queda con tu logo, a pantalla completa.
3. Es la misma app y los mismos datos en los dos: lo que registres en uno aparece en el otro (se sincroniza solo, también si uno estuvo sin internet). En la tablet gira libremente y usa una barra lateral y varias columnas.
4. **Para que los avisos lleguen con la app cerrada** (Honor): Ajustes del teléfono → Batería → Inicio de aplicaciones → Chrome/Cava → desactiva la gestión automática y permite el inicio automático y la actividad en segundo plano. Luego en la app: **⚙ Ajustes → Servidor → Activar push en este celular → Probar**.
- Si algún aparato **no tiene servicios de Google**, Chrome puede no estar disponible y el push no funcionaría ahí; el canal fiable serían los avisos por WhatsApp.
- *Opcional:* para un archivo APK sin Chrome, sube tu dirección a https://www.pwabuilder.com y genera el paquete Android.

## 3. Pasar tus datos de la versión de prueba
En la versión anterior: **Despachos → Respaldo de datos → Mostrar mis datos** y copia el texto. En Cava: **⚙ Ajustes → Respaldo de datos → pega → Importar** (tócalo dos veces para confirmar).

## 4. Funciones
| Pestaña | Qué hace |
|---|---|
| Inicio | Resumen: alertas (vencidos, stock bajo, despachos), ganancia neta, cobrado, pagado, inventario y posición neta |
| Vender | Ventas con plazo de pago; pueden quedar **pendientes de despachar** |
| Despacho | Pedidos pendientes por cliente; **✅ Despachado** los convierte en venta y baja el stock |
| Cobrar | Saldos por vencimiento, abonos, **nota de venta**, cobro por WhatsApp con +58 |
| Stock | Entradas, salidas y aviso de stock mínimo |
| Compras | Proveedores con precios guardados, deudas y cuál te rinde más |
| Reportes | Gráficas por mes y semana, clientes en riesgo, quién debe y quién tarda en pagar |
| ⚙ Ajustes | Datos del negocio, tema de color, recordatorios con sonido, servidor, respaldo, cerrar sesión |

**Nota de venta:** botón *Factura* en Cobrar y en el historial de Vender. Sale como **foto JPG en blanco y negro** (no PDF), con tu logo, el cliente, los productos, los kilos, el precio por unidad, el total en $, lo abonado y el saldo; junta las ventas del mismo cliente y fecha. *Compartir* abre el menú de Android (elige WhatsApp y el chat); *Guardar foto* la deja en Descargas. Lleva el aviso "Documento informativo. No sustituye a una factura fiscal."

## 5. WhatsApp y correo (cuando quieras activarlos)
**WhatsApp** (recordatorios a clientes y resumen para ti) usa la *WhatsApp Business Cloud API* de Meta; solo se puede escribir primero con **plantillas aprobadas**.
1. En https://developers.facebook.com crea una app con WhatsApp y un número de negocio. Guarda el *Phone number ID* (`WA_PHONE_ID`) y un token permanente (`WA_TOKEN`).
2. Crea dos plantillas (categoría *Utilidad*, español) y espera su aprobación:
   - `recordatorio_pago`: `Hola {{1}}, te recordamos que tienes un saldo pendiente de {{2}}, vencido desde el {{3}}. ¿Cuándo podrías realizar el pago? Gracias.`
   - `resumen_diario`: `Resumen de hoy: {{1}}`
3. En Render → **Environment** agrega `WA_TOKEN` y `WA_PHONE_ID` (opcional `WA_LANG`, `WA_TPL_CLIENT`, `WA_TPL_OWNER`). El servidor deja de simular y envía de verdad. Meta cobra por mensaje (revisa tarifas de tu país) y solo debes escribir a clientes que aceptaron recibirlos. Para el logo de perfil del WhatsApp Business usa `icon-512.png`.

**Correo:** agrega `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` (Gmail requiere verificación en dos pasos y una *contraseña de aplicación*). En ⚙ Ajustes → Servidor pon el correo (o varios), elige reporte semanal (lunes) y/o mensual (día 1). Hay **Vista previa** y **Enviar ahora**. Sin esos datos, los envíos se **simulan** y quedan en `/api/log`.

## 6. Seguridad y datos
- PIN con límite de intentos; sesión de 30 días guardada en el servidor; **Cerrar sesión** (⚙ Ajustes) la invalida de verdad. Cabeceras de seguridad (CSP, anti-iframe), datos validados, y el código del servidor nunca se publica.
- Copia de seguridad diaria automática en el servidor (últimos 30 días).
- Si dos aparatos guardan a la vez, la app combina los cambios por registro; lo que uno borró sigue borrado.
- Sin conexión: la app abre, tus cambios quedan en el aparato y se envían solos al volver el internet. Si el servidor rechaza algo, el indicador de la cabecera lo dice.
- **Escala:** con 2 años de ventas (≈6 000) el estado pesa ≈1,6 MB y se envía comprimido (≈190 KB); el servidor admite hasta 50 MB.
- Nunca pongas el PIN ni las claves en el código: van solo en las variables de entorno de Render.

## 7. Probarla en computadora (opcional)
Con Node 18+: `npm install`, luego `APP_PIN=1234 npm start` (Windows PowerShell: `$env:APP_PIN="1234"; npm start`) y abre http://localhost:3000. `npm test` ejecuta 30 pruebas automáticas.

## 8. Estado del proyecto
**Terminado y probado (30 pruebas automáticas + pruebas en Chrome real en 11 tamaños de pantalla):** PIN y sesiones, datos en la nube con combinación de cambios, sin conexión, todas las pantallas, despachos, cobros, compras, stock, reportes, tema de color, logo en blanco y negro, nota de venta en foto JPG, adaptación a teléfono, tablet y horizontal, envío comprimido, rendimiento con 6 000 ventas, accesibilidad de formularios.

**Errores encontrados y corregidos:** cambios sin conexión que no se enviaban y la app decía "Sincronizado"; cambios perdidos al guardar desde dos celulares; sesión imposible de cerrar; servidor que aceptaba datos corruptos; faltaban cabeceras de seguridad; la app no abría sin internet; avisos locales incompatibles con Android; botones menores de 44 px (incluida la barra inferior en pantallas de 320 px); pantalla de PIN improvisada; datos rechazados mostrados como guardados; pantalla Cobrar de 3,5 s con muchas ventas (ahora 70 ms); guardados de 1,6 MB (ahora comprimidos); tope de 5 MB; manchas de render por degradados translúcidos; fechas en formato técnico; barra lateral cortada en teléfono horizontal; métricas mal repartidas en tablet vertical; archivos subibles solo con carpetas (ahora todo va plano, apto para subir desde el celular).

**Lo que falta de tu lado:** crear las cuentas y desplegar (sección 1), conectar WhatsApp y correo si los quieres, y probar el primer día en tu Honor y en tu tablet.

**No verificado por no tener tus aparatos ni tu cuenta de Render:** el aspecto exacto en un Honor y en una Hyundai reales, el menú de compartir fotos de Android, el despliegue en Render, el push a tu celular y los envíos reales de WhatsApp y correo. Lo probado se hizo en un Chrome de escritorio simulando pantallas; avísame de cualquier detalle que veas.
